export default class Cronometro {
  constructor(displayElement) {
      this.displayElement = displayElement;
      this.tiempo = 0;
      this.intervalo = null;
      this.actualizarDisplay();
  }

  actualizarDisplay() {
      const minutos = String(Math.floor(this.tiempo / 60)).padStart(2, '0');
      const segundos = String(this.tiempo % 60).padStart(2, '0');
      this.displayElement.textContent = `${minutos}:${segundos}`;
  }

  iniciar() {
      if (!this.intervalo) {
          this.intervalo = setInterval(() => {
              this.tiempo++;
              this.actualizarDisplay();
          }, 1000);
      }
  }

  pausar() {
      clearInterval(this.intervalo);
      this.intervalo = null;
  }

  reiniciar() {
      this.pausar();
      this.tiempo = 0;
      this.actualizarDisplay();
  }
}