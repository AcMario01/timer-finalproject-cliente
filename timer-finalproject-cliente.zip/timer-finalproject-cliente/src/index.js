import Cronometro from './timer.js';
import './styles.scss';

document.addEventListener('DOMContentLoaded', () => {
    const iniciarBtn = document.getElementById('iniciar');
    const pausarBtn = document.getElementById('pausar');
    const reiniciarBtn = document.getElementById('reiniciar');
    const tiempoDisplay = document.getElementById('tiempoDisplay');

    const cronometro = new Cronometro(tiempoDisplay);

    iniciarBtn.addEventListener('click', () => cronometro.iniciar());
    pausarBtn.addEventListener('click', () => cronometro.pausar());
    reiniciarBtn.addEventListener('click', () => cronometro.reiniciar());
});